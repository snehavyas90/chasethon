const express = require('express');
const app = express();
const PORT = 5000;

app.use(express.json()); // for parsing JSON bodies

// Temporary in-memory data
let students = [
  { id: 1, name: "Harshita", age: 19 },
  { id: 2, name: "Aman", age: 20 }
];

// ----------- CRUD Routes ------------

// GET all students
app.get('/students', (req, res) => {
  res.json(students);
});

// GET student by ID
app.get('/students/:id', (req, res) => {
  const student = students.find(s => s.id === parseInt(req.params.id));
  if (!student) return res.status(404).send("Student not found");
  res.json(student);
});

// POST - add new student
app.post('/students', (req, res) => {
  const newStudent = {
    id: students.length + 1,
    name: req.body.name,
    age: req.body.age
  };
  students.push(newStudent);
  res.status(201).json(newStudent);
});

// PUT - update student by ID
app.put('/students/:id', (req, res) => {
  const student = students.find(s => s.id === parseInt(req.params.id));
  if (!student) return res.status(404).send("Student not found");

  student.name = req.body.name || student.name;
  student.age = req.body.age || student.age;

  res.json(student);
});

// DELETE - remove student by ID
app.delete('/students/:id', (req, res) => {
  const studentIndex = students.findIndex(s => s.id === parseInt(req.params.id));
  if (studentIndex === -1) return res.status(404).send("Student not found");

  const deletedStudent = students.splice(studentIndex, 1);
  res.json(deletedStudent);
});

// -------------------------------------
app.get('/', (req, res) => {
  res.send('Welcome to the Student CRUD API 🚀');
});


app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
