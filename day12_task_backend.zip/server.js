const express = require("express");
const cors = require("cors");
const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

// Temporary in-memory tasks
let tasks = [
  { id: 1, text: "Learn Node.js" },
  { id: 2, text: "Practice React" }
];

// GET all tasks
app.get("/tasks", (req, res) => {
  res.json(tasks);
});

// POST - add new task
app.post("/tasks", (req, res) => {
  const newTask = { id: tasks.length + 1, text: req.body.text };
  tasks.push(newTask);
  res.status(201).json(newTask);
});

// DELETE - remove task
app.delete("/tasks/:id", (req, res) => {
  const id = parseInt(req.params.id);
  tasks = tasks.filter(task => task.id !== id);
  res.json({ message: "Task deleted" });
});

app.listen(PORT, () => {
  console.log(`✅ Backend running on http://localhost:${PORT}`);
});
